package org.eposoft.jccd.parser;

/**
 * @author biegel
 */
public class ParseException extends Exception {

	private static final long serialVersionUID = 582310145422784722L;

}
