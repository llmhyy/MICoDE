package org.eposoft.jccd.data;

/**
 * Used for comparisons in one single version.
 * 
 * @author biegel
 */
public final class PoolSingle extends APool {

}
